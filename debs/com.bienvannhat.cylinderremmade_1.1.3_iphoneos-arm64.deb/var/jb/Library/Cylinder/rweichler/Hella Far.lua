return function(page, offset)
    page:translate(-offset)
end
