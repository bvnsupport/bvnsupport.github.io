Background widgets can be set to lie atop the user's wallpaper, on both the Lockscreen and Homescreen.

See here for further information: https://incendo.ws/documentation/widget-api/additional-documentation/widget-layout.html
