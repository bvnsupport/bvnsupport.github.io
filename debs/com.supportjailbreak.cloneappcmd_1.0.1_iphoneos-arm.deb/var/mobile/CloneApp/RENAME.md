# Phiên bản mã hóa nguồn mở
# Copyright (C) 2020 Shinigami
# Phiên bản v1.0.1 support For Ios 14
# Gõ lệnh cloneapp <app> để chạy