#import <Preferences/PSSpecifier.h>
#import <Preferences/PSListController.h>

extern NSString *const PLBundleKey;
extern NSString *const PLFilterKey;
extern NSString *const PLAlternatePlistNameKey;

@interface PSListController (libprefs)
- (NSArray *)specifiersFromEntry:(NSDictionary *)entry sourcePreferenceLoaderBundlePath:(NSString *)sourceBundlePath title:(NSString *)title;
@end

@interface PSSpecifier (libprefs)
@property (nonatomic, retain, readonly) NSBundle *preferenceLoaderBundle;
+ (BOOL)environmentPassesPreferenceLoaderFilter:(NSDictionary *)filter;
@end

@interface PLCustomListController: PSListController { }
@end

@interface PLLocalizedListController: PLCustomListController { }
@end
