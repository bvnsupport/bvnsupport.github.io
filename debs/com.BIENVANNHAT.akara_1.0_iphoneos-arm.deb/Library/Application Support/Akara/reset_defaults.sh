#!/bin/sh

cp /Library/Application\ Support/Akara/ModuleConfiguration_Akara.plist /var/mobile/Library/ControlCenter/
cp /Library/Application\ Support/Akara/com.tr1roo.akara.providedakaramodule.0.plist /var/mobile/Library/Preferences/
cp /Library/Application\ Support/Akara/com.tr1roo.akara.providedakaramodule.1.plist /var/mobile/Library/Preferences/
cp /Library/Application\ Support/Akara/com.tr1roo.akara.providedakaraverticalmodule.0.plist /var/mobile/Library/Preferences/