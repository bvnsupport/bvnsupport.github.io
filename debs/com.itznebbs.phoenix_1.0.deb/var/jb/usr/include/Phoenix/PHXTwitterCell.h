#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIImage+Private.h>
#import <UIKit/UIKit.h>
#import <rootless.h>

@interface PHXTwitterCell : PSTableCell
@property (nonatomic, retain) UIView *baseView;
@property (nonatomic, retain) UIImageView *avatarView;
@property (nonatomic, retain) UILabel *nameLabel;
@property (nonatomic, retain) UILabel *bioLabel;
@end