#import <Preferences/PSSliderTableCell.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIImage+Private.h>
#import "PHXImage.h"

@interface PSSpecifier (PHXSliderCell)
- (id)performGetter;
- (void)performSetterWithValue:(id)value;
@end

@interface UIView (PHXSliderCell)
- (UIViewController *)_viewControllerForAncestor;
@end

@interface PHXSliderCell : PSSliderTableCell {
	UILabel *_sliderLabel;
	UILabel *_valueLabel;
	UIStackView *_controlStackView;
	UIStackView *_sliderStackView;
}
@end