#import <Foundation/Foundation.h>
#import <CoreText/CoreText.h>
#import <UIKit/UIKit.h>

@interface PHXSystem : NSObject
+ (NSString *)timeWithFormat:(NSString *)format;
+ (NSString *)dateWithFormat:(NSString *)format;
+ (NSString *)fontWithPath:(NSString *)fontPath;
@end