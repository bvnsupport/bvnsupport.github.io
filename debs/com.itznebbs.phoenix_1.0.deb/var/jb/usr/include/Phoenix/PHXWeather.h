#import <objc/runtime.h>
#import <UIKit/UIKit.h>

@interface WALockscreenWidgetViewController : UIViewController
- (id)_temperature;
- (id)_conditionsImage;
- (void)_updateTodayView;
- (void)updateWeather;
@end

@interface PHXWeather : NSObject
@property (nonatomic, retain, readonly) WALockscreenWidgetViewController *weatherWidget;
+ (instancetype)sharedInstance;
- (void)refreshWeatherData;
- (NSString *)temperature;
- (UIImage *)conditionsImage;
@end