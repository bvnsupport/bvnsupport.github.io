#import <Foundation/Foundation.h>

@interface NSAttributedString (JCX)
+ (instancetype)stringWithFormat:(NSString *)format, ...;
@end
