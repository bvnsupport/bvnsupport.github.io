#import "JCXTableCell.h"

@interface JCXGradientHeaderCellBlurContentView : UIView {
    CAShapeLayer * _Nonnull _borderLayer;
}
@end
