#import "JCXTableCell.h"

@interface JCXDisclosureCell : JCXTableCell
@end
